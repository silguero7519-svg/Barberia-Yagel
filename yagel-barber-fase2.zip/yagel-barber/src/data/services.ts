export type Service = {
  id: string;
  slug: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
  isActive: boolean;
};

export const demoServices: Service[] = [
  { id: "1", slug: "corte-clasico", name: "Corte clásico", description: "Corte personalizado adaptado a tu estilo.", price: 15000, durationMinutes: 45, isActive: true },
  { id: "2", slug: "corte-barba", name: "Corte + Barba", description: "El combo completo: precisión en el corte y perfilado de barba.", price: 20000, durationMinutes: 60, isActive: true },
  { id: "3", slug: "fade", name: "Fade", description: "Degradé milimétrico, de piel a largo en una sola línea.", price: 18000, durationMinutes: 50, isActive: true },
  { id: "4", slug: "barba", name: "Barba", description: "Perfilado y diseño de barba con navaja.", price: 10000, durationMinutes: 30, isActive: true },
  { id: "5", slug: "corte-premium", name: "Corte Premium", description: "Experiencia completa: corte, barba, toalla caliente y styling.", price: 25000, durationMinutes: 75, isActive: true },
];

export function formatPrice(value: number) {
  return value.toLocaleString("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 });
}
