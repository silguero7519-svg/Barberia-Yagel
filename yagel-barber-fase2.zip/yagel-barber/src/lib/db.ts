import { PrismaClient } from "@prisma/client";

// Evita crear una nueva instancia de PrismaClient en cada hot-reload de
// Next.js en desarrollo (agotaría las conexiones a la base de datos).
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
