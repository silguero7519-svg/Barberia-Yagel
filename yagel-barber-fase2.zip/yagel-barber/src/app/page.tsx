import Hero from "@/components/public/Hero";
import ServicesSection from "@/components/public/ServicesSection";

export default function Home() {
  return (
    <>
      <Hero />
      <ServicesSection />
    </>
  );
}
