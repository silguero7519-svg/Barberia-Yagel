import Link from "next/link";
import BladeLine from "./BladeLine";

export default function Hero() {
  return (
    <section className="relative min-h-[100svh] flex items-center overflow-hidden bg-yb-black yb-grain">
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 55% at 78% 20%, rgba(201,162,39,0.16) 0%, rgba(5,5,5,0) 60%), radial-gradient(45% 40% at 10% 85%, rgba(201,162,39,0.08) 0%, rgba(5,5,5,0) 60%)",
        }}
        aria-hidden="true"
      />
      <svg className="absolute inset-0 w-full h-full opacity-[0.07]" aria-hidden="true" preserveAspectRatio="none">
        <line x1="0%" y1="30%" x2="100%" y2="22%" stroke="#E5C766" strokeWidth="1" />
        <line x1="0%" y1="78%" x2="100%" y2="85%" stroke="#E5C766" strokeWidth="1" />
      </svg>

      <div className="relative z-10 mx-auto max-w-6xl w-full px-5 md:px-8 pt-28 pb-20">
        <p className="yb-fade-up font-mono text-[11px] yb-tracked uppercase text-yb-gold/80 mb-6">
          Barbería premium
        </p>

        <h1 className="yb-fade-up font-display text-[15vw] leading-[0.9] md:text-[7.5rem] md:leading-[0.88] text-yb-white">
          <span className="italic">Yagel</span>
          <br />
          <span className="text-yb-gold">Barber</span>
        </h1>

        <BladeLine className="w-full max-w-md mt-8 mb-8" />

        <p className="yb-fade-up font-sans text-base md:text-lg text-yb-white/70 max-w-md" style={{ animationDelay: "0.15s" }}>
          Barbería premium para quienes saben que un buen corte hace la diferencia.
        </p>

        <div className="yb-fade-up mt-10 flex flex-col sm:flex-row gap-4" style={{ animationDelay: "0.25s" }}>
          <Link href="/reservar" className="inline-flex items-center justify-center bg-yb-gold text-yb-black text-xs yb-tracked uppercase font-semibold px-8 py-4 hover:bg-yb-gold-light transition-colors">
            Reservar turno
          </Link>
          <Link href="/servicios" className="inline-flex items-center justify-center border border-yb-white/25 text-yb-white text-xs yb-tracked uppercase px-8 py-4 hover:border-yb-gold hover:text-yb-gold transition-colors">
            Ver servicios
          </Link>
        </div>
      </div>
    </section>
  );
}
