import Link from "next/link";
import { demoServices, formatPrice } from "@/data/services";
import BladeLine from "./BladeLine";

export default function ServicesSection() {
  const services = demoServices.filter((s) => s.isActive);

  return (
    <section id="servicios" className="bg-yb-black py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <div className="max-w-lg">
          <p className="font-mono text-[11px] yb-tracked uppercase text-yb-gold/80 mb-4">Servicios</p>
          <h2 className="font-display italic text-4xl md:text-5xl text-yb-white">Precisión en cada corte</h2>
          <BladeLine className="w-24 mt-6" />
        </div>

        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-yb-gold/10">
          {services.map((service) => (
            <article key={service.id} className="group bg-yb-surface p-8 flex flex-col justify-between min-h-[220px] hover:bg-yb-black-2 transition-colors">
              <div>
                <h3 className="font-display italic text-2xl text-yb-white mb-2">{service.name}</h3>
                <p className="text-sm text-yb-white/60 leading-relaxed">{service.description}</p>
              </div>
              <div className="mt-8 flex items-end justify-between">
                <div>
                  <p className="font-mono text-lg text-yb-gold">{formatPrice(service.price)}</p>
                  <p className="font-mono text-[11px] text-yb-white/40 mt-1">{service.durationMinutes} min</p>
                </div>
                <Link href={`/reservar?servicio=${service.slug}`} className="font-mono text-[11px] yb-tracked uppercase text-yb-white/70 border-b border-transparent group-hover:border-yb-gold group-hover:text-yb-gold transition-colors pb-0.5">
                  Reservar →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
