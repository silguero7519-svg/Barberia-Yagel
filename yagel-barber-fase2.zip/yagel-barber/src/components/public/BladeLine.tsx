"use client";

import { useEffect, useRef, useState } from "react";

export default function BladeLine({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <span
      ref={ref}
      className={`yb-blade ${inView ? "yb-blade--in" : ""} ${className}`}
      aria-hidden="true"
    />
  );
}
