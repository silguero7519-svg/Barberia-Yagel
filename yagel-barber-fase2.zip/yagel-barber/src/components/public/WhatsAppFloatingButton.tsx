import { whatsappLink } from "@/data/site-config";

export default function WhatsAppFloatingButton() {
  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="¿Tenés alguna consulta? Escribinos por WhatsApp"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-yb-gold text-yb-black flex items-center justify-center shadow-[0_8px_24px_rgba(201,162,39,0.35)] hover:bg-yb-gold-light transition-colors"
    >
      <svg viewBox="0 0 32 32" width="26" height="26" fill="currentColor" aria-hidden="true">
        <path d="M16.02 3C9.4 3 4 8.36 4 14.94c0 2.34.62 4.53 1.79 6.42L4 29l7.86-1.75a12.9 12.9 0 0 0 4.16.7h.01c6.62 0 12.02-5.36 12.02-11.94C28.05 8.36 22.65 3 16.02 3Zm0 21.68h-.01a10 10 0 0 1-5.1-1.4l-.37-.22-4.66 1.04 1.05-4.51-.24-.38a9.83 9.83 0 0 1-1.53-5.27C5.16 9.5 10 4.7 16.02 4.7c2.79 0 5.42 1.09 7.4 3.06a10.36 10.36 0 0 1 3.06 7.18c0 5.44-4.84 9.74-10.46 9.74Zm5.7-7.3c-.31-.16-1.85-.91-2.14-1.02-.29-.1-.5-.16-.71.16-.21.31-.81 1.02-1 1.23-.18.21-.37.23-.68.08-.31-.16-1.32-.48-2.51-1.53-.93-.82-1.55-1.84-1.74-2.15-.18-.31-.02-.48.14-.63.14-.14.31-.37.47-.55.16-.18.21-.31.31-.52.1-.21.05-.39-.03-.55-.08-.16-.71-1.68-.97-2.31-.26-.6-.52-.52-.71-.53h-.6c-.21 0-.55.08-.84.39-.29.31-1.1 1.06-1.1 2.6 0 1.53 1.13 3.01 1.29 3.22.16.21 2.22 3.36 5.38 4.71.75.32 1.34.51 1.8.66.76.24 1.44.2 1.99.13.61-.09 1.85-.75 2.11-1.48.26-.73.26-1.35.18-1.48-.08-.13-.29-.21-.6-.36Z" />
      </svg>
    </a>
  );
}
