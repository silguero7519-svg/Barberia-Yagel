import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding YAGEL BARBER...");

  // Servicios demo (punto 41 del brief) — mismos valores que src/data/services.ts
  // (esa data local se elimina en la Fase 4, cuando el front pase a leer de acá)
  const services = [
    { slug: "corte-clasico", name: "Corte clásico", description: "Corte personalizado adaptado a tu estilo.", price: 15000, durationMinutes: 45 },
    { slug: "corte-barba", name: "Corte + Barba", description: "El combo completo: precisión en el corte y perfilado de barba.", price: 20000, durationMinutes: 60 },
    { slug: "fade", name: "Fade", description: "Degradé milimétrico, de piel a largo en una sola línea.", price: 18000, durationMinutes: 50 },
    { slug: "barba", name: "Barba", description: "Perfilado y diseño de barba con navaja.", price: 10000, durationMinutes: 30 },
    { slug: "corte-premium", name: "Corte Premium", description: "Experiencia completa: corte, barba, toalla caliente y styling.", price: 25000, durationMinutes: 75 },
  ];

  for (const service of services) {
    await prisma.service.upsert({
      where: { slug: service.slug },
      update: service,
      create: service,
    });
  }

  // Horario laboral demo: Lunes a Sábado, mañana y tarde (punto 23)
  const businessHours = [
    { dayOfWeek: 1, startTime: "09:00", endTime: "13:00" },
    { dayOfWeek: 1, startTime: "15:00", endTime: "20:00" },
    { dayOfWeek: 2, startTime: "09:00", endTime: "13:00" },
    { dayOfWeek: 2, startTime: "15:00", endTime: "20:00" },
    { dayOfWeek: 3, startTime: "09:00", endTime: "13:00" },
    { dayOfWeek: 3, startTime: "15:00", endTime: "20:00" },
    { dayOfWeek: 4, startTime: "09:00", endTime: "13:00" },
    { dayOfWeek: 4, startTime: "15:00", endTime: "20:00" },
    { dayOfWeek: 5, startTime: "09:00", endTime: "13:00" },
    { dayOfWeek: 5, startTime: "15:00", endTime: "20:00" },
    { dayOfWeek: 6, startTime: "09:00", endTime: "14:00" },
  ];

  await prisma.businessHour.deleteMany({});
  await prisma.businessHour.createMany({ data: businessHours });

  // Configuración inicial (punto 28) — % de seña, moneda
  await prisma.setting.upsert({
    where: { key: "deposit_percentage" },
    update: { value: "50" },
    create: { key: "deposit_percentage", value: "50" },
  });
  await prisma.setting.upsert({
    where: { key: "currency" },
    update: { value: "ARS" },
    create: { key: "currency", value: "ARS" },
  });

  // Admin inicial — CAMBIAR la contraseña en el primer login
  const passwordHash = await bcrypt.hash("changeme123", 10);
  await prisma.admin.upsert({
    where: { email: "admin@yagelbarber.com" },
    update: {},
    create: {
      name: "Admin",
      email: "admin@yagelbarber.com",
      passwordHash,
      role: "OWNER",
    },
  });

  console.log("Seed completo. Admin: admin@yagelbarber.com / changeme123 (cambiar el password real).");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
