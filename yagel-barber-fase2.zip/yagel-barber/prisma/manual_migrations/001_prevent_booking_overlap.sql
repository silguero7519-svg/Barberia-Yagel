-- YAGEL BARBER — Fase 2
-- Defensa de última línea contra el doble turno (overbooking), a nivel de base
-- de datos. El motor de disponibilidad de la aplicación es la primera línea
-- de defensa, pero nunca hay que confiar únicamente en el código de la app
-- para algo tan crítico como esto: si dos requests llegan al mismo tiempo
-- (race condition), esta constraint es la que realmente lo impide.
--
-- Cómo aplicarla (después de correr `npx prisma migrate dev --name init`):
--   npx prisma db execute --file prisma/manual_migrations/001_prevent_booking_overlap.sql --schema prisma/schema.prisma

CREATE EXTENSION IF NOT EXISTS btree_gist;

ALTER TABLE "bookings"
  ADD CONSTRAINT "bookings_no_overlap"
  EXCLUDE USING gist (
    "date" WITH =,
    tsrange("startTime", "endTime") WITH &&
  )
  WHERE (status::text IN ('PENDING_PAYMENT', 'CONFIRMED', 'ATTENDED'));

-- Notas:
-- * Turnos CANCELLED o NO_SHOW quedan fuera de la exclusión: liberan el horario.
-- * Si en el futuro `startTime`/`endTime` pasan a @db.Timestamptz, cambiar
--   tsrange(...) por tstzrange(...) en esta constraint.
