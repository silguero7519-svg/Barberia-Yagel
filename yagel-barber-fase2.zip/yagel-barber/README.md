# YAGEL BARBER

Sitio web + sistema de gestión de turnos para barbería premium.

## Estado actual: Fase 2 — Base de datos (Prisma + PostgreSQL)

### Fase 1 (diseño visual) — recordatorio
Next.js 16 + TypeScript + Tailwind v4, paleta negro/dorado, tipografías de marca
(Instrument Serif / Manrope / Space Mono), firma visual "El Filo", Navbar, Hero,
Servicios (con datos demo en `src/data/services.ts`), Footer, botón de WhatsApp.

### Fase 2 — lo que se agregó ahora

- **`prisma/schema.prisma`**: las 14 tablas del modelo (admins, clients, services,
  bookings, payments, business_hours, blocked_dates, blocked_slots, social_links,
  gallery, settings, notifications, qr_codes, audit_logs), con sus relaciones.
- **`prisma/manual_migrations/001_prevent_booking_overlap.sql`**: el `EXCLUDE`
  constraint de PostgreSQL que impide el doble turno a nivel de base de datos
  (defensa de última línea, además del motor de disponibilidad que se construye
  en la Fase 5). Prisma no soporta declarar `EXCLUDE` en el schema, por eso es
  SQL manual — se aplica en un paso aparte, ver más abajo.
- **`prisma/seed.ts`**: carga los 5 servicios demo, el horario laboral de
  lunes a sábado, la configuración inicial (seña 50%, moneda ARS) y un
  usuario admin inicial.
- **`docker-compose.yml`**: PostgreSQL 16 local, listo para desarrollo.
- **`.env.example`**: variables necesarias.
- **`src/lib/db.ts`**: cliente Prisma singleton (seguro para hot-reload de Next.js).

### Cómo levantarlo

```bash
npm install

# 1. Base de datos local
docker compose up -d
cp .env.example .env

# 2. Crear las tablas
npx prisma migrate dev --name init

# 3. Aplicar la constraint anti-solapamiento (una sola vez)
npx prisma db execute --file prisma/manual_migrations/001_prevent_booking_overlap.sql --schema prisma/schema.prisma

# 4. Cargar datos demo
npm run db:seed

# 5. Correr el sitio
npm run dev
```

`npm run db:studio` abre Prisma Studio (`localhost:5555`) para ver/editar los
datos con una interfaz visual — útil para revisar que el seed cargó bien.

**Admin inicial**: `admin@yagelbarber.com` / `changeme123` (hay que cambiar esta
contraseña real cuando se construya el login en la Fase 7 — el hash ya está en
la base, no queda en texto plano).

### Nota importante sobre este entorno de chat

Prisma necesita descargar un motor binario (`schema-engine`) desde
`binaries.prisma.sh` para poder correr `prisma generate`, `migrate` o `validate`.
La sandbox de este chat no tiene salida de red a ese dominio, así que no pude
ejecutar esos comandos acá para verificar el schema de punta a punta — sí lo
revisé línea por línea a mano. En tu máquina, con internet normal, `npm install`
va a poder generar el cliente sin problema. Si algo no valida al correr
`npx prisma migrate dev`, avisame el error exacto y lo corregimos.

## Próximas fases

Fase 3: gestión de clientes · Fase 4: CRUD de servicios desde el panel (reemplaza
`src/data/services.ts`) · Fase 5: motor de disponibilidad · Fase 6: wizard de
reserva · Fase 7: panel administrativo + auth · Fase 8: Mercado Pago (seña 50%)
· Fase 9: WhatsApp · Fase 10: QR · Fase 11: notificaciones · Fase 12:
estadísticas e ingresos · Fase 13: redes sociales · Fase 14: SEO y performance.
