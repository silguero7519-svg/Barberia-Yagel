import Link from "next/link";
import { navLinks, siteConfig } from "@/data/site-config";

const social = [
  { label: "Instagram", href: siteConfig.instagram },
  { label: "Facebook", href: siteConfig.facebook },
  { label: "TikTok", href: siteConfig.tiktok },
];

export default function Footer() {
  return (
    <footer className="bg-yb-black border-t border-yb-gold/10">
      <div className="mx-auto max-w-6xl px-5 md:px-8 py-16 grid grid-cols-1 md:grid-cols-3 gap-10">
        <div>
          <p className="font-display italic text-3xl text-yb-white">
            Yagel<span className="text-yb-gold not-italic"> Barber</span>
          </p>
          <p className="mt-3 text-sm text-yb-white/50 font-mono">{siteConfig.tagline}</p>
        </div>

        <div>
          <p className="font-mono text-[11px] yb-tracked uppercase text-yb-white/40 mb-4">
            Navegación
          </p>
          <ul className="space-y-2 text-sm text-yb-white/70">
            {navLinks.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-yb-gold transition-colors">
                  {l.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/reservar" className="hover:text-yb-gold transition-colors">
                Reservar
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <p className="font-mono text-[11px] yb-tracked uppercase text-yb-white/40 mb-4">
            Seguinos
          </p>
          <ul className="space-y-2 text-sm text-yb-white/70">
            {social.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-yb-gold transition-colors"
                >
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-yb-gold/10 py-6">
        <p className="text-center text-[11px] font-mono text-yb-white/35 yb-tracked uppercase">
          © {new Date().getFullYear()} Yagel Barber — Todos los derechos reservados
        </p>
      </div>
    </footer>
  );
}
