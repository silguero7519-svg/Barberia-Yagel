"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { navLinks } from "@/data/site-config";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-500 ${
        scrolled ? "bg-yb-black/90 backdrop-blur-md border-b border-yb-gold/15" : "bg-transparent"
      }`}
    >
      <nav className="mx-auto max-w-6xl px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
        <Link href="/" className="font-display text-2xl md:text-3xl italic text-yb-white">
          Yagel<span className="text-yb-gold not-italic"> Barber</span>
        </Link>

        <ul className="hidden md:flex items-center gap-8 font-sans text-xs yb-tracked uppercase text-yb-white/80">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link href={link.href} className="hover:text-yb-gold transition-colors">
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <Link
          href="/reservar"
          className="hidden md:inline-flex items-center border border-yb-gold text-yb-gold text-xs yb-tracked uppercase px-5 py-2.5 hover:bg-yb-gold hover:text-yb-black transition-colors"
        >
          Reservar turno
        </Link>

        <button
          aria-label="Abrir menú"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="md:hidden flex flex-col justify-center gap-1.5 w-9 h-9"
        >
          <span
            className={`h-px bg-yb-gold transition-all ${open ? "rotate-45 translate-y-[3px]" : ""}`}
          />
          <span
            className={`h-px bg-yb-gold transition-all ${open ? "-rotate-45 -translate-y-[3px]" : ""}`}
          />
        </button>
      </nav>

      {open && (
        <div className="md:hidden bg-yb-black border-t border-yb-gold/15 px-5 pb-6 pt-2">
          <ul className="flex flex-col gap-4 font-sans text-sm yb-tracked uppercase text-yb-white/85">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} onClick={() => setOpen(false)} className="block py-1">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
          <Link
            href="/reservar"
            onClick={() => setOpen(false)}
            className="mt-5 inline-flex w-full items-center justify-center border border-yb-gold text-yb-gold text-xs yb-tracked uppercase px-5 py-3"
          >
            Reservar turno
          </Link>
        </div>
      )}
    </header>
  );
}
