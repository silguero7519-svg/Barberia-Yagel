// Estos valores hoy son estáticos. En la Fase 28 (Panel de configuración) pasan
// a leerse desde la tabla `settings` y se administran desde /admin/configuracion.

export const siteConfig = {
  name: "YAGEL BARBER",
  tagline: "Tu estilo. Nuestra precisión.",
  whatsappNumber: "5491100000000", // reemplazar por el número real
  whatsappDefaultMessage: "Hola YAGEL BARBER, quiero reservar un turno.",
  address: "Dirección a confirmar",
  instagram: "https://instagram.com/yagelbarber",
  facebook: "https://facebook.com/yagelbarber",
  tiktok: "https://tiktok.com/@yagelbarber",
  depositPercentage: 50,
};

export const navLinks = [
  { label: "Inicio", href: "/" },
  { label: "Servicios", href: "/servicios" },
  { label: "Nosotros", href: "/#nosotros" },
  { label: "Galería", href: "/galeria" },
  { label: "Contacto", href: "/contacto" },
];

export function whatsappLink(customMessage?: string) {
  const msg = encodeURIComponent(customMessage ?? siteConfig.whatsappDefaultMessage);
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${msg}`;
}
