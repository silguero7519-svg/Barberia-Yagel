# YAGEL BARBER

Sitio web + sistema de gestión de turnos para barbería premium.

## Estado actual: Fase 1 — Diseño visual y estructura

Lo que está construido en esta entrega:

- Proyecto Next.js 16 (App Router) + TypeScript + Tailwind CSS v4.
- Sistema de diseño (`src/app/globals.css`): paleta negro/dorado, tipografías de marca
  (Instrument Serif para títulos, Manrope para texto, Space Mono para precios/etiquetas),
  y el elemento de firma visual **"El Filo"**: una línea dorada que se dibuja como el
  trazo de una navaja al entrar en pantalla (`BladeLine.tsx`), usada como divisor en
  todo el sitio.
- `Navbar` sticky con menú hamburguesa en mobile.
- `Hero` de impacto con headline, CTAs y fondo generado en CSS/SVG (sin depender de
  fotos con derechos — reemplazar por fotografía real del local cuando esté disponible).
- `ServicesSection` con tarjetas conectadas a `src/data/services.ts` (datos demo del
  punto 41 del brief — en la Fase 2/4 se reemplaza por consultas reales a la base de
  datos vía Prisma, sin tocar el componente visual).
- `Footer` con navegación, redes sociales y datos configurables.
- Botón flotante de WhatsApp.
- Metadata SEO base (title, description, Open Graph).

Todo lo que hoy vive en `src/data/site-config.ts` (WhatsApp, redes, % de seña) está
aislado a propósito: en la Fase 28 pasa a leerse desde la tabla `settings` y se
administra desde `/admin/configuracion`, sin tener que tocar los componentes.

## Cómo correrlo

```bash
npm install
npm run dev
```

Abrir http://localhost:3000

## Próximas fases (ver documento de arquitectura)

Fase 2: base de datos (Prisma + PostgreSQL) · Fase 3: clientes · Fase 4: CRUD de
servicios desde el panel · Fase 5: motor de disponibilidad · Fase 6: wizard de reserva
· Fase 7: panel administrativo · Fase 8: Mercado Pago (seña 50%) · Fase 9: WhatsApp
· Fase 10: QR · Fase 11: notificaciones · Fase 12: estadísticas e ingresos · Fase 13:
redes sociales · Fase 14: SEO y performance.
